import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.ImageDraw

#Open the matrix picture in numpy
directory = os.path.dirname(os.path.abspath(__file__))  
filepath_matrix = os.path.join(directory, 'matrix.jpg')
matrix_numpy = plt.imread(filepath_matrix)

#Open Kobe in numpy
filepath_kobe = os.path.join(directory, 'kobe.JPG')
kobe_numpy = plt.imread(filepath_kobe)

# Open the mask picture in numpy.
filepath_mask = os.path.join(directory, 'mask.JPG')
mask_numpy = plt.imread(filepath_mask)

# Open the text picture in numpy
filepath_woke = os.path.join(directory, 'woke.JPG')
woke_numpy = plt.imread(filepath_woke)

# Convert all pictures to PIL
kobe_image_pil = PIL.Image.fromarray(kobe_numpy)
mask_image_pil = PIL.Image.fromarray(mask_numpy)
matrix_image_pil = PIL.Image.fromarray(matrix_numpy)
woke_image_pil = PIL.Image.fromarray(woke_numpy)


# Places kobe and mask on matrix bg
matrix_image_pil.paste(kobe_image_pil,(550,350))
matrix_image_pil.paste(mask_image_pil,(194,164))
matrix_image_pil.paste(woke_image_pil,(456,22))
matrix_numpy = np.array(matrix_image_pil)

# Makes Kobe's glasses black
for r in range(492,553):
    for c in range(700,884):
        if sum(matrix_numpy[r][c])<200:
            matrix_numpy[r][c] = [0,0,0]
for r in range(492,547):
    for c in range(852,884):
        if sum(matrix_numpy[r][c])>0:
            matrix_numpy[r][c] = [0,0,0]
            
# Makes Mask background blend in more with the background
for r in range(159,348):
    for c in range(190,430):
        if sum(matrix_numpy[r][c])>700:
            matrix_numpy[r][c] = [4,35,0]
for r in range(348,480):
    for c in range(190,430):
        if sum(matrix_numpy[r][c])>700:
            matrix_numpy[r][c] = [16,48,12]
            
fig, ax = plt.subplots(1, 1)
ax.imshow(matrix_numpy, interpolation='none')
fig.show()